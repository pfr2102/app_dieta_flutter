package com.example.dam_u2_app_basica_19400568

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
